package com.example.foodorder.view.contact;

import com.example.foodorder.model.Contact;

import java.util.List;

public interface ContactMVPView {
    void loadListContacts(List<Contact> list);
}
