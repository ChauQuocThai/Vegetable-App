package com.example.foodorder.listener;

import com.example.foodorder.model.Food;

public interface IOnClickFoodItemListener {
    void onClickItemFood(Food food);
}
