package com.example.foodorder.view.feedback;

public interface FeedbackMVPView {
    void sendFeedbackSuccess();
}
