package com.example.foodorder.view.splash;

public interface SplashMVPView {
}
