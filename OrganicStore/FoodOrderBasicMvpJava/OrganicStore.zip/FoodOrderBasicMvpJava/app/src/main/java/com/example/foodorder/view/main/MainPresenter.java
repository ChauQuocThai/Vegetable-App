package com.example.foodorder.view.main;

public class MainPresenter {

    private final MainMVPView mMainMVPView;

    public MainPresenter(MainMVPView mMainMVPView) {
        this.mMainMVPView = mMainMVPView;
    }
}
